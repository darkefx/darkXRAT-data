to use full apk 
just extract full apk

go to android studio and import extracted folder.
whole app will be shifted there.

remaiing task on server endpoint